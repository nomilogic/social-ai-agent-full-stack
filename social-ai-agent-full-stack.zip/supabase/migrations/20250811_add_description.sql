
-- Add description field to companies table
ALTER TABLE companies ADD COLUMN description TEXT;
